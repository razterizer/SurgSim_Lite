#g++ lapsim_lite.cpp -lSDL2 -o lapsim_lite
#g++ lapsim_lite.cpp -lncurses -o lapsim_lite
#export XDG_RUNTIME_DIR=/tmp
g++ lapsim_lite.cpp -o lapsim_lite -std=c++2a -O3
#./lapsim_lite
