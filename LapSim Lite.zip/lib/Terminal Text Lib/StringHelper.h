#pragma once
#include <string>

std::string rep_char(char c, int num)
{
  std::string ret;
  for (int i=0; i<num; ++i)
    ret += c;
  return ret;
}
