#pragma once
#include <string>
#include <vector>

class Text
{

  template<typename EnumType>
  constexpr int to_int(EnumType e) const noexcept
  {
    return static_cast<int>(e);
  }

public:

  enum class Color
  {
    Transparent = -1,
    Transparent2 = -2,
    Default = 0,
    Black,
    DarkRed,
    DarkGreen,
    DarkYellow,
    DarkBlue,
    DarkMagenta,
    DarkCyan,
    LightGray,
    DarkGray,
    Red,
    Green,
    Yellow,
    Blue,
    Magenta,
    Cyan,
    White
  };

  std::string get_color_string(Color text_color, Color bg_color = Color::Default) const
  {
    if (bg_color == Color::Transparent || bg_color == Color::Transparent2)
      bg_color = Color::Default;
    std::string fg = "\033[";
    std::string bg = "\033[";
    if (text_color == Color::Default)
      fg += "39";
    else if (Color::Default < text_color && text_color <= Color::LightGray)
      fg += std::to_string(to_int(text_color) + 29);
    else
      fg += std::to_string(to_int(text_color) + 81);

    if (bg_color == Color::Default)
      bg += "49";
    else if (Color::Default < bg_color && bg_color <= Color::LightGray)
      bg += std::to_string(to_int(bg_color) + 39);
    else
      bg += std::to_string(to_int(bg_color) + 91);

    fg += "m";
    bg += "m";
    return fg + bg;
  }

  void print(const std::string& text, Color text_color, Color bg_color = Color::Default) const
  {
    std::string output = get_color_string(text_color, bg_color) + text + "\033[0m";
    printf("%s", output.c_str());
  }

  void print_line(const std::string& text, Color text_color, Color bg_color = Color::Default) const
  {
    print(text, text_color, bg_color);
    printf("\n");
  }

  void print_char(char c, Color text_color, Color bg_color = Color::Default) const
  {
    std::string output = get_color_string(text_color, bg_color) + c;
    printf("%s", output.c_str());
  }

  void print_complex(const std::vector<std::tuple<char, Color, Color>>& text)
  {
    size_t n = text.size();
    std::string output;
    for (size_t i = 0; i < n; ++i)
    {
      const auto& ti = text[i];
      char c = std::get<0>(ti);
      auto fg_color = std::get<1>(ti);
      auto bg_color = std::get<2>(ti);
      auto col_str = get_color_string(fg_color, c == '\n' ? Color::Default : bg_color);
      std::string char_str(1, c);
      output += col_str + char_str;
    }
    output += "\033[0m";
    printf("%s", output.c_str());
  }

  void print_reset() const
  {
    printf("%s", "\033[0m");
  }
};

